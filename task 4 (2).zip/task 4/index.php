<?php
session_start();
require 'db.php';

$search = $_GET['search'] ?? '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 5;
$start = ($page - 1) * $limit;

$whereSQL = '';
$values = [];

if (!empty($search)) {
    $whereSQL = "WHERE title LIKE ? OR content LIKE ?";
    $values[] = "%$search%";
    $values[] = "%$search%";
}

$countQuery = "SELECT COUNT(*) FROM posts $whereSQL";
$stmt = $conn->prepare($countQuery);
$stmt->execute($values);
$totalPosts = $stmt->fetchColumn();
$totalPages = ceil($totalPosts / $limit);

$query = "SELECT posts.*, users.username FROM posts
          JOIN users ON posts.user_id = users.id
          $whereSQL ORDER BY created_at DESC LIMIT ?, ?";
$values[] = (int)$start;
$values[] = (int)$limit;

$stmt = $conn->prepare($query);
$stmt->execute($values);
$posts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Blog Posts</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(to right, #fff8dc, #ffeeba);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .post-card {
            background-color: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
        }
        .post-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(0,0,0,0.1);
        }
        .btn-read-more {
            margin-right: 0.5rem;
        }
        .pagination a.active {
            background-color: #f0ad4e;
            color: white;
        }
        .welcome-bar {
            background-color: #fff3cd;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
            text-align: center;
            font-weight: 500;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="mb-4 text-center"> Blog Posts ✍️</h1>

    <div class="welcome-bar">
        <?php if (isset($_SESSION['user_id'])): ?>
            Welcome, <?= htmlspecialchars($_SESSION['username']) ?> (<?= htmlspecialchars($_SESSION['role']) ?>) |
            <a href="create_post.php">Create Post</a> |
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="admin.php">Admin Panel</a> |
            <?php endif; ?>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a> |
            <a href="register.php">Register</a>
        <?php endif; ?>
    </div>

    <form method="GET" class="d-flex mb-4">
        <input type="search" name="search" class="form-control me-2" placeholder="Search posts..." value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-warning text-white" type="submit">Search</button>
    </form>

    <?php foreach ($posts as $row): ?>
        <div class="post-card">
            <h3>
                <a href="view_post.php?id=<?= $row['id'] ?>" class="text-decoration-none text-primary fw-bold">
                    <?= htmlspecialchars($row['title']) ?>
                </a>
            </h3>
            <small class="text-muted d-block mb-2">
                By <?= htmlspecialchars($row['username']) ?> on <?= date('M j, Y', strtotime($row['created_at'])) ?>
            </small>
            <p class="text-muted"><?= nl2br(htmlspecialchars(substr($row['content'], 0, 200))) ?>...</p>
            <a href="view_post.php?id=<?= $row['id'] ?>" class="btn btn-outline-primary btn-sm btn-read-more">Read More</a>

            <?php if (isset($_SESSION['user_id']) && ($_SESSION['user_id'] == $row['user_id'] || $_SESSION['role'] === 'admin')): ?>
                <a href="edit_post.php?id=<?= $row['id'] ?>" class="btn btn-outline-warning btn-sm">✏️ Edit</a>
                <a href="delete_post.php?id=<?= $row['id'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete this post?')">🗑️ Delete</a>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>

    <div class="pagination mt-4 text-center">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a class="btn btn-outline-secondary <?= ($i == $page) ? 'active' : '' ?>"
               href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
