<?php
require 'db.php';
session_start();

// Validate and fetch post ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Invalid post ID.";
    exit();
}

$post_id = (int) $_GET['id'];

// Fetch the post
$stmt = $conn->prepare("SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id WHERE posts.id = ?");
$stmt->execute([$post_id]);
$post = $stmt->fetch();

if (!$post) {
    echo "Post not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($post['title']) ?> | My Blog</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #eef2f3, #8e9eab);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: 60px;
        }
        .post-container {
            background-color: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .post-container:hover {
            transform: translateY(-5px);
        }
        .post-title {
            font-size: 2rem;
            font-weight: 700;
            color: #343a40;
        }
        .post-meta {
            color: #6c757d;
            font-size: 0.9rem;
        }
        .post-content {
            margin-top: 1.5rem;
            line-height: 1.7;
            color: #495057;
        }
        .back-btn {
            margin-top: 2rem;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="post-container mx-auto col-md-8">
        <h1 class="post-title"><?= htmlspecialchars($post['title']) ?></h1>
        <p class="post-meta">By <?= htmlspecialchars($post['username']) ?> on <?= date('F j, Y', strtotime($post['created_at'])) ?></p>
        <hr>
        <div class="post-content">
            <?= nl2br(htmlspecialchars($post['content'])) ?>
        </div>
        <a href="index.php" class="btn btn-outline-primary back-btn">← Back to Blog</a>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const postContainer = document.querySelector('.post-container');
        postContainer.addEventListener('mouseover', () => {
            postContainer.style.boxShadow = '0 12px 25px rgba(0,0,0,0.15)';
        });
        postContainer.addEventListener('mouseout', () => {
            postContainer.style.boxShadow = '0 10px 30px rgba(0,0,0,0.1)';
        });
    });
</script>
</body>
</html>
