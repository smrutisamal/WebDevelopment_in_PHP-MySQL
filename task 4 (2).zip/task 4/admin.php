<?php
session_start();
require 'db.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Get all users
$stmt = $conn->prepare("SELECT id, username, role, created_at FROM users ORDER BY created_at DESC");
$stmt->execute();
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4">Admin Panel</h1>

    <div class="mb-3">
        <a href="index.php" class="btn btn-secondary">← Back to Blog</a>
    </div>

    <h2 class="mb-3">User Management</h2>
    <div class="table-responsive">
        <table class="table table-hover">
           <thead class="table-dark">
    <tr>
      <th>ID</th>
      <th>Username</th>
      <th>Role</th>
      <th>Joined</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($users as $user): ?>
      <tr class="animate__animated animate__fadeIn">
        <td><?= $user['id'] ?></td>
        <td><?= htmlspecialchars($user['username']) ?></td>
        <td>
          <form method="POST" action="update_role.php" class="d-inline">
            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
            <select name="role" class="form-select form-select-sm"
                    onchange="this.form.submit()"
                    style="cursor: pointer; width: auto; display: inline-block;">
              <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>👤 User</option>
              <option value="editor" <?= $user['role'] === 'editor' ? 'selected' : '' ?>>✏️ Editor</option>
              <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>👑 Admin</option>
            </select>
          </form>
        </td>
        <td><?= date('M j, Y', strtotime($user['created_at'])) ?></td>
        <td>
          <?php if ($user['id'] != $_SESSION['user_id']): ?>
            <button class="btn btn-sm btn-outline-danger"
                    onclick="confirmDelete(<?= $user['id'] ?>)">
              🗑️ Delete
            </button>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>

    </table>
    <script>
function confirmDelete(userId) {
  if (confirm('Are you sure you want to delete this user and all their posts?')) {
    window.location.href = `delete_user.php?id=${userId}`;
  }
}
</script>

    </div>
</div>
</body>
</html>
