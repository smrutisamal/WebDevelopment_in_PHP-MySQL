<?php
session_start();
require 'db.php';

$errors = [];
$username = '';
$password = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    // Validation
    if (empty($username)) $errors['username'] = 'Username is required';
    elseif (strlen($username) < 4) $errors['username'] = 'Username must be at least 4 characters';
    elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) $errors['username'] = 'Only letters, numbers and underscores allowed';

    if (empty($password)) $errors['password'] = 'Password is required';
    elseif (strlen($password) < 8) $errors['password'] = 'Password must be at least 8 characters';

    if ($password !== $confirm_password) $errors['confirm_password'] = 'Passwords do not match';

    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);

            if ($stmt->rowCount() > 0) {
                $errors['username'] = 'Username already taken';
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
                $stmt->execute([$username, $hashed_password]);

                $_SESSION['user_id'] = $conn->lastInsertId();
                $_SESSION['username'] = $username;
                header("Location: login.php");
                exit();
            }
        } catch (PDOException $e) {
            $errors['database'] = 'Registration failed. Please try again.';
            error_log("Registration Error: " . $e->getMessage());
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Blog</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --success: #00b894;
            --dark: #2d3436;
            --light: #f8f9fa;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .auth-container {
            max-width: 450px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 0.6s;
        }

        .auth-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            color: white;
            padding: 2rem;
            text-align: center;
        }

        .auth-body {
            padding: 2rem;
        }

        .form-control {
            padding: 12px 15px;
            border-radius: 8px;
        }

        .input-group-text {
            background: transparent;
            border-right: 0;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(108, 92, 231, 0.25);
        }

        .btn-success {
            background-color: var(--success);
            border-color: var(--success);
            padding: 12px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .btn-success:hover {
            background-color: #00a884;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 184, 148, 0.4);
        }

        .auth-footer {
            text-align: center;
            padding: 1.5rem;
            background: var(--light);
        }

        .password-strength {
            height: 4px;
            background: #e9ecef;
            margin-top: 5px;
            border-radius: 2px;
            overflow: hidden;
        }

        .strength-bar {
            height: 100%;
            width: 0;
            background: #dc3545;
            transition: width 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="d-flex align-items-center">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="auth-container animate__animated animate__fadeIn">
                <div class="auth-header">
                    <h2><i class="fas fa-user-plus me-2"></i>Create Account</h2>
                    <p class="mb-0">Join our community today</p>
                </div>

                <div class="auth-body">
                    <?php if (!empty($errors['database'])): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($errors['database']) ?></div>
                    <?php endif; ?>

                    <form method="POST" novalidate>
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                                <input type="text" name="username" class="form-control <?= isset($errors['username']) ? 'is-invalid' : '' ?>"
                                       placeholder="Choose a username" value="<?= htmlspecialchars($username) ?>" required>
                            </div>
                            <?php if (isset($errors['username'])): ?>
                                <div class="invalid-feedback d-block"><?= htmlspecialchars($errors['username']) ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" name="password" id="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>"
                                       placeholder="Create a password" required>
                            </div>
                            <div class="password-strength">
                                <div class="strength-bar" id="strengthBar"></div>
                            </div>
                            <?php if (isset($errors['password'])): ?>
                                <div class="invalid-feedback d-block"><?= htmlspecialchars($errors['password']) ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Confirm Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" name="confirm_password" class="form-control <?= isset($errors['confirm_password']) ? 'is-invalid' : '' ?>"
                                       placeholder="Confirm your password" required>
                            </div>
                            <?php if (isset($errors['confirm_password'])): ?>
                                <div class="invalid-feedback d-block"><?= htmlspecialchars($errors['confirm_password']) ?></div>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-success w-100 mb-3">
                            <i class="fas fa-user-plus me-2"></i>Register
                        </button>
                    </form>
                </div>

                <div class="auth-footer">
                    <p class="mb-0">Already have an account? <a href="login.php" class="text-primary fw-bold">Sign in</a></p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Password strength indicator
    document.getElementById('password').addEventListener('input', function() {
        const strengthBar = document.getElementById('strengthBar');
        const password = this.value;
        let strength = 0;

        if (password.length > 0) strength += 1;
        if (password.length >= 8) strength += 1;
        if (/[A-Z]/.test(password)) strength += 1;
        if (/[0-9]/.test(password)) strength += 1;
        if (/[^A-Za-z0-9]/.test(password)) strength += 1;

        const width = strength * 20;
        strengthBar.style.width = width + '%';

        if (strength < 2) {
            strengthBar.style.backgroundColor = '#dc3545';
        } else if (strength < 4) {
            strengthBar.style.backgroundColor = '#fd7e14';
        } else {
            strengthBar.style.backgroundColor = '#28a745';
        }
    });

    // Client-side validation
    document.querySelector('form').addEventListener('submit', function(e) {
        let valid = true;
        const username = document.querySelector('[name="username"]');
        const password = document.querySelector('[name="password"]');
        const confirm_password = document.querySelector('[name="confirm_password"]');

        // Clear previous errors
        document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));

        // Username validation
        if (username.value.trim() === '') {
            showError(username, 'Username is required');
            valid = false;
        } else if (username.value.trim().length < 4) {
            showError(username, 'Username must be at least 4 characters');
            valid = false;
        } else if (!/^[a-zA-Z0-9_]+$/.test(username.value.trim())) {
            showError(username, 'Only letters, numbers and underscores allowed');
            valid = false;
        }

        // Password validation
        if (password.value.trim() === '') {
            showError(password, 'Password is required');
            valid = false;
        } else if (password.value.trim().length < 8) {
            showError(password, 'Password must be at least 8 characters');
            valid = false;
        }

        // Confirm password
        if (password.value !== confirm_password.value) {
            showError(confirm_password, 'Passwords do not match');
            valid = false;
        }

        if (!valid) e.preventDefault();
    });

    function showError(input, message) {
        input.classList.add('is-invalid');
        const errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback d-block';
        errorDiv.textContent = message;
        input.parentNode.parentNode.appendChild(errorDiv);
    }
    </script>
</body>
</html>
