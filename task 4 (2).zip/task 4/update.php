<?php
session_start();
require 'db.php';

// Only allow admins to update roles
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'] ?? null;
    $role = $_POST['role'] ?? null;

    // Validate role
    $allowed_roles = ['user', 'editor', 'admin'];
    if (!in_array($role, $allowed_roles)) {
        $_SESSION['error'] = 'Invalid role specified';
        header("Location: admin.php");
        exit();
    }

    try {
        // Prevent self-demotion (admins can't remove their own admin status)
        if ($user_id == $_SESSION['user_id'] && $role !== 'admin') {
            $_SESSION['error'] = 'You cannot remove your own admin status';
            header("Location: admin.php");
            exit();
        }

        $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
        $stmt->execute([$role, $user_id]);

        $_SESSION['success'] = 'User role updated successfully';
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Failed to update user role: ' . $e->getMessage();
    }
}

header("Location: admin.php");
exit();
?>
