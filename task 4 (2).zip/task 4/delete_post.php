<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: index.php");
    exit();
}

try {
    // Check if user owns the post or is admin
    $stmt = $conn->prepare("SELECT user_id FROM posts WHERE id = ?");
    $stmt->execute([$id]);
    $post = $stmt->fetch();

    if (!$post) {
        $_SESSION['error'] = 'Post not found';
        header("Location: index.php");
        exit();
    }

    if ($post['user_id'] == $_SESSION['user_id'] || $_SESSION['role'] === 'admin') {
        $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['success'] = 'Post deleted successfully';
    } else {
        $_SESSION['error'] = 'You are not authorized to delete this post';
    }
} catch (PDOException $e) {
    $_SESSION['error'] = 'Failed to delete post: ' . $e->getMessage();
}

header("Location: index.php");
exit();
?>
