<?php
session_start();
require 'db.php';

// Only allow admins to delete users
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: admin.php");
    exit();
}

// Prevent self-deletion
if ($id == $_SESSION['user_id']) {
    $_SESSION['error'] = 'You cannot delete your own account';
    header("Location: admin.php");
    exit();
}

try {
    // First delete user's posts
    $stmt = $conn->prepare("DELETE FROM posts WHERE user_id = ?");
    $stmt->execute([$id]);

    // Then delete the user
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);

    $_SESSION['success'] = 'User and their posts deleted successfully';
} catch (PDOException $e) {
    $_SESSION['error'] = 'Failed to delete user: ' . $e->getMessage();
}

header("Location: admin.php");
exit();
?>
