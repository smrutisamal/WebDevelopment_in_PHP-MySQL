<?php include 'db.php'; ?>
<?php
$id = $_GET['id'];
$stmt = $conn->prepare("SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id WHERE posts.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$post = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlspecialchars($post['title']); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1><?php echo htmlspecialchars($post['title']); ?></h1>
    <p>by <?php echo htmlspecialchars($post['username']); ?></p>
    <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
    <a href="index.php">Back to Posts</a>
</div>
</body>
</html>