<?php include 'db.php'; session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Blog Posts</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Blog Posts</h1>
    <?php if (isset($_SESSION['user_id'])): ?>
        <p>Welcome, <?php echo $_SESSION['username']; ?> | <a href="create_post.php">Create New Post</a> | <a href="logout.php">Logout</a></p>
    <?php else: ?>
        <p><a href="login.php">Login</a> | <a href="register.php">Register</a></p>
    <?php endif; ?>
    <ul>
        <?php
        $result = $conn->query("SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id ORDER BY created_at DESC");
        while ($row = $result->fetch_assoc()): ?>
            <li>
                <a href="view_post.php?id=<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['title']); ?></a>
                by <?php echo htmlspecialchars($row['username']); ?>
                <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $row['user_id']): ?>
                    - <a href="edit_post.php?id=<?php echo $row['id']; ?>">Edit</a>
                    - <a href="delete_post.php?id=<?php echo $row['id']; ?>">Delete</a>
                <?php endif; ?>
            </li>
        <?php endwhile; ?>
    </ul>
</div>
</body>
</html>