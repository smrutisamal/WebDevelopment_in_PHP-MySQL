-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2025 at 09:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'Post ID (auto)',
  `title` varchar(255) NOT NULL COMMENT 'Post title',
  `content` text NOT NULL COMMENT 'Full Post content',
  `created_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Time post was created',
  `user_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `created_at`, `user_id`) VALUES
(1, 'My Self', 'Hello, I\'m Shraddha Suman, a dedicated and passionate student programmer with a keen interest in machine learning and software development. I\'ve gained hands-on experience in building Java-related projects and backend applications, and I\'m excited to continue learning and growing in the field of technology.', '2025-06-08 11:33:20', 1),
(3, 'XYZ', 'My first PHP blog project', '2025-06-08 12:16:59', 4),
(4, 'Welcome', 'Hello this is my Project. I am Shraddha', '2025-06-08 12:33:09', 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'User ID (auto)',
  `username` varchar(100) NOT NULL COMMENT 'Login username',
  `password` varchar(255) NOT NULL COMMENT 'Hashed password',
  `created_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Registration Time'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'shraddha.badatiya@gmail.com', '$2y$10$RUZR8YK7RclR/GIK8Nts8.2IWIMpgPOmRvheMhwGgTTi/LEwmhq9e', '2025-06-08 11:28:28'),
(4, 'shraddha.suman@gmail.com', '$2y$10$fwXKgMZtnVQnvZ3XbR4XBu/LJSoA7x1i.EqkFiOuInvUFyI07C5lq', '2025-06-08 12:15:55'),
(5, 'xyz@gmail.com', '$2y$10$iAzoXl4RvJ6DVxo77NrJ5OvmBx/1H13l2vmEt.M0mWnTO6akC7Sh2', '2025-06-08 12:32:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Post ID (auto)', AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'User ID (auto)', AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
