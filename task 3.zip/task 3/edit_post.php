<?php
session_start();
include 'db.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch post for editing
$post_id = $_GET['id'] ?? null;
if (!$post_id) {
    header("Location: index.php");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM posts WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $post_id, $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$post = $result->fetch_assoc();

if (!$post) {
    echo "<div class='alert alert-danger'>Post not found or unauthorized access.</div>";
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);

    if ($title && $content) {
        $stmt = $conn->prepare("UPDATE posts SET title = ?, content = ? WHERE id = ?");
        $stmt->bind_param("ssi", $title, $content, $post_id);
        if ($stmt->execute()) {
            header("Location: view_post.php?id=$post_id");
            exit();
        } else {
            $error = "❌ Failed to update post. Please try again.";
        }
    } else {
        $error = "⚠️ All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Post</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #fff3e0, #ffffff);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 16px;
        }
        .form-container {
            max-width: 600px;
            margin: 80px auto;
            background: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 12px 24px rgba(0,0,0,0.1);
        }
        .form-label {
            font-weight: 600;
        }
        textarea.form-control {
            resize: vertical;
        }
        .btn-primary {
            background-color: #fb8c00;
            border-color: #fb8c00;
        }
        .btn-primary:hover {
            background-color: #ef6c00;
        }
        h2 {
            font-weight: bold;
            color: #333;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="form-container">
        <h2 class="mb-4 text-center">✏️ Edit Blog Post</h2>

        <?php if ($error): ?>
            <div class="alert alert-warning text-center"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Title</label>
                <input type="text" name="title" value="<?= htmlspecialchars($post['title']) ?>" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Content</label>
                <textarea name="content" rows="8" class="form-control" required><?= htmlspecialchars($post['content']) ?></textarea>
            </div>
            <div class="d-flex justify-content-between">
                <a href="index.php" class="btn btn-outline-secondary">← Back</a>
                <button type="submit" class="btn btn-primary">Update Post</button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
