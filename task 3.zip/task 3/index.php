<?php
session_start();
include 'db.php';

$search = $_GET['search'] ?? '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 5;
$start = ($page - 1) * $limit;

// Prepare WHERE clause for search
$whereSQL = '';
$params = [];
$paramTypes = '';

if (!empty($search)) {
    $whereSQL = "WHERE title LIKE ? OR content LIKE ?";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $paramTypes = "ss";
}

// Count total posts
$countQuery = "SELECT COUNT(*) FROM posts $whereSQL";
$stmt = $conn->prepare($countQuery);
if (!empty($params)) {
    $stmt->bind_param($paramTypes, ...$params);
}
$stmt->execute();
$stmt->bind_result($totalPosts);
$stmt->fetch();
$stmt->close();

$totalPages = ceil($totalPosts / $limit);

// Fetch posts with pagination
$query = "SELECT posts.*, users.username FROM posts
          JOIN users ON posts.user_id = users.id
          $whereSQL ORDER BY created_at DESC LIMIT ?, ?";
$params[] = $start;
$params[] = $limit;
$paramTypes .= "ii";

$stmt = $conn->prepare($query);
$stmt->bind_param($paramTypes, ...$params);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Blog Home</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background: linear-gradient(to bottom right,rgb(250, 212, 192),rgb(248, 183, 208)); /* light yellow to peachy cream */
        min-height: 100vh;
        margin: 0;
        padding: 0;
    }
    </style>

</head>
<body>
<div class="container">
    <h1 class="mb-4">Blog Posts</h1>

    <!-- Navbar Links -->
    <div class="mb-3">
        <?php if (isset($_SESSION['user_id'])): ?>
            <span>Welcome, <?= $_SESSION['username'] ?></span> |
            <a href="create_post.php">Create Post</a> |
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a> |
            <a href="register.php">Register</a>
        <?php endif; ?>
    </div>

    <!-- Search Form -->
    <form method="GET" class="d-flex mb-4">
        <input type="search" name="search" class="form-control me-2" placeholder="Search posts..." value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-primary" type="submit">Search</button>
    </form>

    <!-- Posts -->
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="border p-3 mb-3 rounded shadow-sm">
            <h3><a href="view_post.php?id=<?= $row['id'] ?>"><?= htmlspecialchars($row['title']) ?></a></h3>
            <small>By <?= htmlspecialchars($row['username']) ?> on <?= $row['created_at'] ?></small>
            <p><?= nl2br(htmlspecialchars(substr($row['content'], 0, 150))) ?>...</p>
            <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $row['user_id']): ?>
                <a href="edit_post.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="delete_post.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
            <?php endif; ?>
        </div>
    <?php endwhile; ?>

    <!-- Pagination -->
    <div class="pagination mt-4">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a class="btn btn-outline-secondary <?= ($i == $page) ? 'active' : '' ?>" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
</div>
</body>
</html>
