<?php
session_start();
include 'db.php';

$post_id = $_GET['id'] ?? null;
if (!$post_id) {
    header("Location: index.php");
    exit();
}

$stmt = $conn->prepare("SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id WHERE posts.id = ?");
$stmt->bind_param("i", $post_id);
$stmt->execute();
$result = $stmt->get_result();
$post = $result->fetch_assoc();

if (!$post) {
    echo "<div class='alert alert-danger'>Post not found.</div>";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Post</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #fffde7, #ffe082);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 16px;
        }
        .post-container {
            max-width: 1000px;
            margin: 80px auto;
            background: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 12px 24px rgba(0,0,0,0.1);
        }
        h2 {
            font-weight: bold;
            color: #333;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="post-container">
        <h2><?= htmlspecialchars($post['title']) ?></h2>
        <p class="text-muted">By <?= htmlspecialchars($post['username']) ?> on <?= $post['created_at'] ?></p>
        <div class="border rounded p-3 bg-light">
            <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>
        </div>

        <div class="mt-4 d-flex justify-content-between">
            <a href="index.php" class="btn btn-outline-secondary">← Back to Home</a>
            <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $post['user_id']): ?>
                <div>
                    <a href="edit_post.php?id=<?= $post['id'] ?>" class="btn btn-warning">Edit</a>
                    <a href="delete_post.php?id=<?= $post['id'] ?>" class="btn btn-danger">Delete</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>

